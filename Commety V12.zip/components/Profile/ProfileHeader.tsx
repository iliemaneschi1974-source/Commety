import { MapPin } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { InfoRow } from "@/components/ui/info-row"
import { Progress } from "@/components/ui/progress"
import { ProfileHeaderData } from "@/types/profile"

interface ProfileHeaderProps {
  profile: ProfileHeaderData
}

export function ProfileHeader({ profile }: ProfileHeaderProps) {
  const progress =
    profile.nextLevelXp > 0
      ? Math.min((profile.currentXp / profile.nextLevelXp) * 100, 100)
      : 0

  const initials = profile.nickname
    .trim()
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase()

  return (
    <div
      data-slot="profile-header"
      className="flex flex-col items-center gap-5"
    >
      <Avatar className="size-28 ring-2 ring-primary/10">
        {profile.avatarUrl && (
          <AvatarImage
            src={profile.avatarUrl}
            alt={profile.nickname}
          />
        )}

        <AvatarFallback className="text-3xl font-semibold">
          {initials}
        </AvatarFallback>
      </Avatar>

      <div className="flex flex-col items-center gap-2 text-center">
        <h1 className="text-2xl font-bold tracking-tight">
          {profile.nickname}
        </h1>

        <InfoRow icon={<MapPin className="size-4" />}>
          {profile.city
            ? `${profile.city} • Iscritto da ${profile.joinedAt}`
            : `Iscritto da ${profile.joinedAt}`}
        </InfoRow>

        {profile.title && (
          <p className="text-sm text-muted-foreground">
            {profile.title}
          </p>
        )}
      </div>

      <div className="flex w-full max-w-sm flex-col gap-3">
        <div className="flex items-center justify-between">
          <Badge>Livello {profile.level}</Badge>

          <span className="text-sm text-muted-foreground">
            {profile.currentXp} / {profile.nextLevelXp} XP
          </span>
        </div>

        <Progress value={progress} />
      </div>
    </div>
  )
}