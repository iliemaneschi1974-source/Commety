"use client"

import { ProfileHeader } from "@/components/Profile/ProfileHeader"
import { Card, CardContent } from "@/components/ui/card"
import { profileHeaderMock } from "@/lib/mock/profile"

export default function ProfilePage() {
  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 p-6">
      <Card>
        <CardContent className="py-8">
          <ProfileHeader profile={profileHeaderMock} />
        </CardContent>
      </Card>
    </main>
  )
}