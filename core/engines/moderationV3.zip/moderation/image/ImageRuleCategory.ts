/**
 * Identifica la famiglia funzionale
 * di una ImageRule.
 *
 * La categoria è utilizzata esclusivamente
 * a fini organizzativi e di orchestrazione
 * del motore di moderazione immagini.
 */
export enum ImageRuleCategory {

  /**
   * Qualità dell'immagine.
   */
  QUALITY = "QUALITY",

  /**
   * Sicurezza dei contenuti.
   */
  SAFETY = "SAFETY",

  /**
   * Tutela della privacy.
   */
  PRIVACY = "PRIVACY",

  /**
   * Analisi semantica e contestuale.
   */
  SEMANTIC = "SEMANTIC"

}