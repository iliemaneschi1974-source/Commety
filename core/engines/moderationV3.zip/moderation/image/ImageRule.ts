import { ImageAnalysis } from "../../../domain/ImageAnalysis";
import { ModerationEvidence } from "../ModerationEvidence";

/**
 * Rappresenta una singola regola di moderazione
 * applicata al risultato dell'analisi di un'immagine.
 *
 * Ogni implementazione osserva esclusivamente
 * un determinato aspetto dell'immagine
 * (es. screenshot, nudità, watermark, violenza...)
 * e produce eventuali evidenze di moderazione.
 *
 * Le regole sono completamente indipendenti tra loro
 * e rispettano il principio di Single Responsibility.
 */
export interface ImageRule {

  /**
   * Analizza il risultato prodotto
   * dall'Image Analysis Engine.
   *
   * @param analysis Analisi dell'immagine.
   * @returns Evidenze eventualmente prodotte.
   */
  analizza(
    analysis: ImageAnalysis
  ): readonly ModerationEvidence[];

}