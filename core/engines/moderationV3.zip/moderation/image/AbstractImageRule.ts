import { ImageAnalysis } from "../../../domain/ImageAnalysis";
import { ModerationEvidence } from "../ModerationEvidence";
import { ImageRule } from "./ImageRule";

/**
 * Classe base per tutte le ImageRule.
 *
 * Fornisce il contratto comune e rappresenta
 * il punto di estensione per eventuali
 * funzionalità condivise tra le regole.
 *
 * Attualmente non introduce logica comune,
 * ma evita duplicazioni future mantenendo
 * omogenea l'architettura del motore.
 */
export abstract class AbstractImageRule implements ImageRule {

  /**
   * Analizza una singola immagine.
   */
  abstract analizza(
    analysis: ImageAnalysis
  ): readonly ModerationEvidence[];

}