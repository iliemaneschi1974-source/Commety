"use client";

import { useEffect } from "react";
import { useMap } from "react-leaflet";
import { useMapContext } from "@/contexts/MapContext";

export default function RecenterMap() {
  const map = useMap();

  const {
    center,
    zoom,
    bounds,
  } = useMapContext();

  useEffect(() => {
    if (bounds) {
      const southWest: [number, number] = [
        bounds[0],
        bounds[2],
      ];

      const northEast: [number, number] = [
        bounds[1],
        bounds[3],
      ];

      map.flyToBounds(
        [southWest, northEast],
        {
          padding: [60, 60],
          maxZoom: 17,
          animate: true,
          duration: 1.3,
        }
      );

      return;
    }

    map.flyTo(center, zoom, {
      animate: true,
      duration: 1.4,
      easeLinearity: 0.25,
    });
  }, [bounds, center, zoom, map]);

  return null;
}