import { Timestamp } from "firebase/firestore";

/**
 * Verifica se una segnalazione può essere prorogata.
 *
 * La proroga è consentita soltanto se:
 *
 * - la segnalazione non è già scaduta;
 * - siamo entrati nella extension window;
 * - non è stato raggiunto il limite massimo (maxExpiresAt).
 */
export function canExtendReport(
  expiresAt: Timestamp,
  maxExpiresAt: Timestamp,
  extensionWindow: number
): boolean {
  const now = Date.now();

  const expiresAtMillis = expiresAt.toMillis();
  const maxExpiresAtMillis = maxExpiresAt.toMillis();

  // Segnalazione già scaduta
  if (now >= expiresAtMillis) {
    return false;
  }

  // Raggiunta la durata massima
  if (expiresAtMillis >= maxExpiresAtMillis) {
    return false;
  }

  // Entrati nella finestra di estensione
  return now >= expiresAtMillis - extensionWindow;
}